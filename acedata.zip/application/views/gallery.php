<style>
.mfp-plugin a img{
  widtH:200px;
  padding: 20px;
}
</style>
<div class="page-title-cont page-title-large2-cont bg-gray back" style="background-image: url(<?php echo base_url(); ?>assets/page/gallery.jpg);">
        <div class="relative container align-left">
          <div class="row">

            <div class="col-md-8">
              <h1 class="page-title2"></h1>
            </div>

            <div class="col-md-4">
              <div class="breadcrumbs2 font-poppins">
                <a class="a-inv" href=""></a><span class="slash-divider"></span><span class="bread-current"></span>
              </div>
            </div>

          </div>
        </div>
      </div>


<!-- COTENT CONTAINER -->
<div class="container bs-docs-container">



    <!-- COTENT  -->
    <div class="col-md-12">



      <div id="lightbox" class="mb-70 bs-docs-section">
        <div class="heading-underline h3-line">
          <!-- <h3 class="mb-20"> Our WorkPlace</h3> -->
        </div>
        <div class="row box-with-hover">
          <div class="popup-gallery demo-popup-gallery mfp-plugin">
                <a href="<?php echo base_url(); ?>assets/gallery/1.jpg" title=""><img  src="<?php echo base_url(); ?>assets/gallery/1.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/2.jpg" title=""><img src="<?php echo base_url(); ?>assets/gallery/2.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/3.jpg" title="  "><img src="<?php echo base_url(); ?>assets/gallery/3.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/4.jpg" title=""><img src="<?php echo base_url(); ?>assets/gallery/4.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/5.jpg" title=" "><img src="<?php echo base_url(); ?>assets/gallery/5.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/6.jpg" title=" "><img src="<?php echo base_url(); ?>assets/gallery/6.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/7.jpg" title=""><img src="<?php echo base_url(); ?>assets/gallery/7.jpg" alt="img"></a>
                <a href="<?php echo base_url(); ?>assets/gallery/8.jpg" title=""><img src="<?php echo base_url(); ?>assets/gallery/8.jpg" alt="img"></a>
							 </div>
        </div>


      </div>


    </div>


  </div>
</div>
