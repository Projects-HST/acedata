<style>
.tab-nav-text.font-poppins {
    width: 100px;
}
li{
  list-style-type: none;
}
.service li{
  padding-left: 15px;
  float: left;
}
.icon-list>li [class*=" fa-"] {
  position: relative;left:-20px;
}
.mb-50{
  text-align: left;
}
.listservices{
  margin: auto;width:20%;
}
.fes14-tab-content{
  padding-bottom: 20px;
}
.fes14-tab-title{
  font-size: 32px;
}
</style>

      <div class="page-title-cont page-title-large2-cont bg-gray" style="background-image: url(<?php echo base_url(); ?>assets/images/bg-about-us.jpg);">
        <div class="relative container align-left">
          <div class="row">

            <div class="col-md-8">
              <h1 class="page-title2">Services</h1>
            </div>

            <div class="col-md-4">
              <div class="breadcrumbs2 font-poppins">
                <a class="a-inv" href="">home</a><span class="slash-divider">/</span><span class="bread-current">services</span>
              </div>
            </div>

          </div>
        </div>
      </div>

<!-- ADS 3 -->

      <!-- ADS 4 -->
      <div id="blockquotes2" class="page-section p-130-cont bg-gray">
            <div class="container">
              <blockquote class="bq2-cont text-center ls-1 font-20 pb-0">
                  <p class=" font-18" style="    font-family: Poppins;    font-style: italic;    font-weight: 700;">We are good at what we deliver</p>
                <span class="test-quote-before">“</span>Complex solutions with attention to every detail;<br> our efficient and creative team makes the entire process seamless by providing the highest level of service and quality, no matter the assignment.<span class="test-quote-after">”</span>

              </blockquote>
            </div>
          </div>

      <!-- FEATURES 14 TABS -->
      <div class="page-section">
        <div class="container">

          <!-- TABS NAV -->
          <div class="row">
            <center>
            <div class="col-md-12">

              <ul class="fes14-nav-tabs  nav-tabs bootstrap-tabs service">
                <li class="active"><a href="#manufacture" class="fes14-nav-a" data-toggle="tab">
                <img src="<?php echo base_url(); ?>assets/images/icons/mi.png" class="img-responsive"><div class="tab-nav-text font-poppins">Manufacturing Industries</div></a>
                </li>
                <li><a href="#indus"  class="fes14-nav-a" data-toggle="tab">
                  <img src="<?php echo base_url(); ?>assets/images/icons/ita.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Industry & Trade Associations</div></a>
                </li>
                <li><a href="#retail"  class="fes14-nav-a" data-toggle="tab">
                  <img src="<?php echo base_url(); ?>assets/images/icons/retail.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Retail Section</div></a>
                </li>
                <li><a href="#edu"  class="fes14-nav-a" data-toggle="tab">
                  <img src="<?php echo base_url(); ?>assets/images/icons/education.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Education Institutions</div></a>
                </li>
                <li><a href="#bank"  class="fes14-nav-a" data-toggle="tab">
                  <img src="<?php echo base_url(); ?>assets/images/icons/bank.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Banks & Financial Institutions</div></a>
                </li>
                <li><a href="#book"  class="fes14-nav-a" data-toggle="tab">
                <img src="<?php echo base_url(); ?>assets/images/icons/bp.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Book Publishers</div></a>
                </li>
                <li><a href="#apparel"  class="fes14-nav-a" data-toggle="tab">
                <img src="<?php echo base_url(); ?>assets/images/icons/apparel.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Apparel & Textile</div></a>
                </li>
                <li><a href="#hosp"  class="fes14-nav-a" data-toggle="tab">
                <img src="<?php echo base_url(); ?>assets/images/icons/hospitality.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Hosptiality Industry</div></a>
                </li>
                <li><a href="#health"  class="fes14-nav-a" data-toggle="tab">
                <img src="<?php echo base_url(); ?>assets/images/icons/healthcare.png" class="img-responsive">
                  <div class="tab-nav-text font-poppins">Health Care</div></a>
                </li>

              </ul>

            </div>
          </center>
          </div>

          <!-- TABS CONTENT & IMAGES -->
          <div class="row">

            <!-- TABS CONTENT -->
            <div class="col-md-12 text-center">
              <div class="fes14-tab-content tab-content">

                <!-- TAB 1 -->
                <div class="tab-pane fade in active" id="manufacture">
                    <h2 class="fes14-tab-title font-poppins"><strong>MANUFACTURING INDUSTRIES</strong></h2>
                      <p class="text-center">
                        <ul class="icon-list mb-50 listservices">
                      <li><i class="fa fa-check"></i>Company Profile</li>
                      <li><i class="fa fa-check"></i>Product Catalogues</li>
                      <li><i class="fa fa-check"></i>Annual Reports</li>
                      <li><i class="fa fa-check"></i>Product User Manuals</li>
                      <li><i class="fa fa-check"></i>Newsletters</li>
                      <li><i class="fa fa-check"></i>Posters</li>
                      <li><i class="fa fa-check"></i>Calendars</li>
                      <li><i class="fa fa-check"></i>Greeting Cards</li>
                      <li><i class="fa fa-check"></i>Invitations</li>
                    </ul>
                  </p>
                </div>

                <!-- TAB 2 -->
                <div class="tab-pane fade in " id="indus">
                    <h3 class="fes14-tab-title font-poppins"><strong>INDUSTRY & TRADE ASSOCIATIONS</strong></h3>
                      <p class="text-center">
                        <ul class="icon-list mb-50 listservices">
                      <li><i class="fa fa-check"></i>Trade Fair Publications</li>
                      <li><i class="fa fa-check"></i>News Letters</li>
                      <li><i class="fa fa-check"></i>Bulletins</li>
                      <li><i class="fa fa-check"></i>Annual Reports</li>
                      <li><i class="fa fa-check"></i>Invitations</li>
                      <li><i class="fa fa-check"></i>Seminar Publications</li>
                        </ul>
                  </p>
                </div>

                <!-- TAB 3 -->
                <div class="tab-pane fade in " id="retail">
                    <h3 class="fes14-tab-title font-poppins"><strong>RETAIL SECTION</strong></h3>
                      <p class="text-center">
                        <ul class="icon-list mb-50 listservices">
                      <li><i class="fa fa-check"></i>Publicity Brochures</li>
                      <li><i class="fa fa-check"></i>Calendars</li>
                      <li><i class="fa fa-check"></i>Handbills and Mailers</li>
                      <li><i class="fa fa-check"></i>Posters</li>
                      <li><i class="fa fa-check"></i>Invitations</li>
                      <li><i class="fa fa-check"></i>Flyers</li>
                      <li><i class="fa fa-check"></i>Greeting Cards</li>

                        </ul>
                  </p>
                </div>

                <div class="tab-pane fade in " id="edu">
                    <h3 class="fes14-tab-title font-poppins"><strong>EDUCATIONAL INSTITUTIONS</strong></h3>
                      <p class="text-center">
                        <ul class="icon-list mb-50 listservices">
                      <li><i class="fa fa-check"></i>General Facility Brochures</li>
                      <li><i class="fa fa-check"></i>Departmental Brochures</li>
                      <li><i class="fa fa-check"></i>Placement Profiles</li>
                      <li><i class="fa fa-check"></i>Conference Publications</li>
                      <li><i class="fa fa-check"></i>Student Exercise Notebooks</li>
                      <li><i class="fa fa-check"></i>Posters</li>
                      <li><i class="fa fa-check"></i>Souvenirs/Magazines</li>
                      <li><i class="fa fa-check"></i>Newsletters</li>
                      <li><i class="fa fa-check"></i>College/School Diary/Calendar</li>
                      <li><i class="fa fa-check"></i>Greeting Cards</li>
                      <li><i class="fa fa-check"></i>Invitations</li>
                        </ul>
                  </p>
                </div>


                <div class="tab-pane fade in" id="bank">
                    <h3 class="fes14-tab-title font-poppins"><strong>BANKS & FINANCIAL INSTITUTIONS</strong></h3>
                      <p class="text-center">
                        <ul class="icon-list mb-50 listservices">
                      <li><i class="fa fa-check"></i>Annual Reports</li>
                      <li><i class="fa fa-check"></i>Promotional Publications</li>
                      <li><i class="fa fa-check"></i>Greeting Cards</li>
                      <li><i class="fa fa-check"></i>Invitations</li>
                    </ul>
                  </p>
                </div>

                <div class="tab-pane fade in" id="book">
                    <h3 class="fes14-tab-title font-poppins"><strong>BOOK PUBLISHERS</strong></h3>
                      <p class="text-center">
                        <ul class="icon-list mb-50 listservices">
                      <li><i class="fa fa-check"></i>Books</li>
                      <li><i class="fa fa-check"></i>Posters</li>
                      <li><i class="fa fa-check"></i>Book Review Brochures</li>
                      <li><i class="fa fa-check"></i>Catalogue of Books</li>
                      <li><i class="fa fa-check"></i>Newsletters</li>
                    </ul>
                  </p>
                </div>

              <div class="tab-pane fade in" id="apparel">
                  <h3 class="fes14-tab-title font-poppins"><strong>APPAREL & TEXTILE</strong></h3>
                    <p class="text-center">
                      <ul class="icon-list mb-50 listservices">
                    <li><i class="fa fa-check"></i>General Facility Brochures</li>
                    <li><i class="fa fa-check"></i>Product Brochures</li>
                    <li><i class="fa fa-check"></i>Tags</li>
                    <li><i class="fa fa-check"></i>Insert Cards</li>
                    <li><i class="fa fa-check"></i>Folders</li>
                    <li><i class="fa fa-check"></i>Posters</li>
                    <li><i class="fa fa-check"></i>Annual Reports</li>
                    <li><i class="fa fa-check"></i>Greeting Cards</li>
                    <li><i class="fa fa-check"></i>Invitations</li>
                  </ul>
                </p>
              </div>

              <div class="tab-pane fade in" id="hosp">
                  <h3 class="fes14-tab-title font-poppins"><strong>HOSPITALITY INDUSTRY</strong></h3>
                    <p class="text-center">
                      <ul class="icon-list mb-50 listservices">
                    <li><i class="fa fa-check"></i>Table Menu</li>
                    <li><i class="fa fa-check"></i>Table Place Mats</li>
                    <li><i class="fa fa-check"></i>Newsletters</li>
                    <li><i class="fa fa-check"></i>Posters</li>
                    <li><i class="fa fa-check"></i>Greeting Cards</li>
                    <li><i class="fa fa-check"></i>Invitations</li>

                  </ul>
                </p>
              </div>
              <div class="tab-pane fade in" id="health">
                  <h3 class="fes14-tab-title font-poppins"><strong>HEALTH CARE</strong></h3>
                    <p class="text-center">
                      <ul class="icon-list mb-50 listservices">
                    <li><i class="fa fa-check"></i>General Facility Brochure</li>
                    <li><i class="fa fa-check"></i>Departmental Brochures</li>
                    <li><i class="fa fa-check"></i>Newsletters</li>
                    <li><i class="fa fa-check"></i>Posters</li>
                    <li><i class="fa fa-check"></i>Calendars</li>
                    <li><i class="fa fa-check"></i>Invitations</li>
                    <li><i class="fa fa-check"></i>Greeting Cards</li>

                  </ul>
                </p>
              </div>

              </div>
            </div>

            <!-- IMAGES -->


          </div>
        </div>
      </div>
