<style>.item{margin: 0 0px 30px;}</style>
<div class="container-fluid main-container slider-container">

    <div id="carousel-example-generic" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">

            <!-- First slide -->

            <div class="item active">
              <img src="<?php echo base_url(); ?>assets/slider/slider2.jpg" class="slide-image">

            </div>
            <div class="item ">
              <img src="<?php echo base_url(); ?>assets/slider/18.jpg" class="slide-image">

            </div>


        </div>
        <!-- /.carousel-inner -->

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!-- /.carousel -->

</div>
<!-- /.container -->

<!-- FEATURES 11 WE ARE CREATIVE FONT MONTSERRAT -->
<div id="about" class="page-section">
    <div class="container-fluid">

        <div class="col-md-4 fes1-img-cont wow fadeInUp mt-80">
            <img src="<?php echo base_url(); ?>assets/slider/3.jpg" alt="img">
        </div>

        <div class="col-lg-8 col-md-8 mt-fes11">
            <div class="row">

                <div class="col-lg-3 col-md-12 col-sm-12">
                    <div class="fes1-main-title-cont wow fadeInUp making">
                        <div class="fes1-title-50 font-montserrat ">
                            <strong>Making<br> Our  <br> Mark</strong>
                        </div>
                        <div class="line-5-100"></div>
                    </div>
                </div>

                <div class="col-lg-9 col-md-12" style="margin-top:-80px;">

                    <div class="row">

                        <div class="col-md-6 col-sm-6">
                            <div class="fes11-box wow fadeIn">
                                <div class="fes1-box-icon">
                                  <img src="<?php  echo base_url(); ?>assets/images/icons/technology.png" class="img-responsive">
                                </div>
                                <h3 class="font-montserrat"><strong>Technology</strong></h3>
                                <p>Our technology is at the forefront of innovation that utilizes a revolutionary high-density printing, which can generate accurate, expert quality output at dramatic speed.</p>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <div class="fes11-box wow fadeIn" data-wow-delay="200ms">
                                <div class="fes1-box-icon">
                                    <img src="<?php  echo base_url(); ?>assets/images/icons/solution.png" class="img-responsive">
                                </div>
                                <h3 class="font-montserrat"><strong>Solutions</strong></h3>
                                <p>Our solutions benefit businesses, enterprises and industries of all sizes. Discover wide variety of printing products and services that provide the best possible results.</p>
                            </div>
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-6 col-sm-6">
                            <div class="fes11-box wow fadeIn" data-wow-delay="400ms">
                                <div class="fes1-box-icon">
                                      <img src="<?php  echo base_url(); ?>assets/images/icons/c.png" class="img-responsive">
                                </div>
                                <h3 class="font-montserrat"><strong>Creative </strong></h3>
                                <p>We are all about catering printing needs through a wide range of channels, with innovative and strategic creative direction.</p>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <div class="fes11-box wow fadeIn" data-wow-delay="600ms">
                                <div class="fes1-box-icon">
                                    <img src="<?php  echo base_url(); ?>assets/images/icons/d.png" class="img-responsive">
                                </div>
                                <h3 class="font-montserrat"><strong>Delivery</strong></h3>
                                <p>A high-volume printing, delivering high performance services that exceed customers' expectations.</p>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>

    </div>
</div>



<!-- END PORTFOLIO SECTION 1 -->

<!-- WORK PROCESS 2 FONT MONTSERRAT -->
<div class="container-fluid p-110-cont">
    <div class="row">

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="work-proc2-cont wow fadeIn">
                <div class="work-proc2-icon-cont pos-l-12">
                    01
                </div>

                <p>Passion, Innovation, Busting clichés and Venturing out into new technologies </p>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="work-proc2-cont wow fadeIn" data-wow-delay="200ms">
                <div class="work-proc2-icon-cont">
                    02
                </div>

                <p>State of the Art Equipment to exceed the limits of the printing industry </p>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="work-proc2-cont wow fadeIn" data-wow-delay="400ms">
                <div class="work-proc2-icon-cont">
                    03
                </div>

                <p>Best Management Practices to give you a high level of service and support</p>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="work-proc2-a-cont wow fadeIn" data-wow-delay="600ms">
                <a class="work-proc2-a" href="#">
                    <div class="work-proc2-a-text font-montserrat">
                      We Are
                        <br><span class="border-bot">Ace Data</span>
                    </div>
                    <div class="work-proc2-bg-block"></div>
                </a>
            </div>
        </div>

    </div>
</div>

<!-- TESTIMONIALS CAROUSEL 3 FONT MONTSERRAT -->
<div class="pt-110-b-80-cont pb-md-80 owl-plugin fullwidth-slider owl-bg-black parallax-section font-white" style="background: url(<?php echo base_url(); ?>assets/images/work-proc-bg3.jpg);" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="50">

    <!-- Slide Item -->
    <div class="container">
        <div class="relative">
            <div class="row">

                <div class="col-md-3">
                    <div class="ts3-author-cont">
                        <div class="ts3-author-img">
                            <img class="img-circle" src="<?php echo base_url(); ?>assets/images/testimonials/ts-author.jpg" alt="photo">
                        </div>
                        <div class="ts-author-info text-center">
                            <div class="ts-name font-white">
                                <strong>Amanda Eniston</strong>
                            </div>
                            <div class="ts-type">Doodle inc.</div>
                        </div>

                    </div>
                </div>

                <div class="col-md-9">
                    <blockquote class="testimonial-3">
                        <p class="font-montserrat font-white">Nunc nec dictum purus. Nam porttitor molestie dolor nec lacinia. Donec placerat magna erat, non eleifend neque convallis at. Morbi felis sem, molestie, blandit ac quam. Fusce aliquet, est at rhoncus aliquam vehicu.</p>
                    </blockquote>
                </div>

            </div>
        </div>
    </div>





</div>

<!-- CLIENTS 2 -->
<div class="page-section p-80-cont">
    <div class="container">

        <div class="row">

            <div class="col-xs-6 col-sm-2 client2-item">
                <img alt="client" src="<?php echo base_url(); ?>assets/images/clients/2-9.png">
            </div>

            <div class="col-xs-6 col-sm-2 client2-item">
                <img alt="client" src="<?php echo base_url(); ?>assets/images/clients/3.png">
            </div>

            <div class="col-xs-6 col-sm-2 client2-item">
                <img alt="client" src="<?php echo base_url(); ?>assets/images/clients/5.png">
            </div>

            <div class="col-xs-6 col-sm-2 client2-item">
                <img alt="client" src="<?php echo base_url(); ?>assets/images/clients/4.png">
            </div>

            <div class="col-xs-6 col-sm-2 client2-item">
                <img alt="client" src="<?php echo base_url(); ?>assets/images/clients/8.png">
            </div>

            <div class="col-xs-6 col-sm-2 client2-item">
                <img alt="client" src="<?php echo base_url(); ?>assets/images/clients/2.png">
            </div>

        </div>

    </div>
</div>
