<div class="page-title-cont page-title-large2-cont " style="background-size: cover;background-image: url(<?php echo base_url(); ?>assets/page/about.jpg);background-size:cover;padding-top:240PX;">
         <div class="relative container align-left">
           <div class="row">

             <div class="col-md-8">
               <!--h1 class="page-title2">Portfolio</h1-->
             </div>

             <div class="col-md-4">
               <div class="breadcrumbs2 font-poppins">
                 <!--a class="a-inv" href="">home</a><span class="slash-divider">/</span><span class="bread-current">portfolio</span-->
               </div>
             </div>

           </div>
         </div>
       </div>



  <div id="blockquotes2" class="page-section p-50-cont"  style="">
       <div id="about" class="">
               	<div class="container">
               		<div>
               			<!-- <h3 class="sl2-text font-josefin" >We Are Ace Data<br></h3> -->

                    <div class="blog2-post-prev-text center" style="text-align:center;padding-bottom:40px;font-style: italic;">
                    We walk an extra Mile in building long lasting relationships to deliver world class quality and workmanship. Our  experience and expertise gives an edge, making us a leading digital printing industry that offers a complete one-stop-shop solutions for your projects of all sizes and parameters. Our passion for the quality helps us achieve the Art of Printing.
                    </div>
                    <div class="blog2-post-prev-text center" style="text-align:center;font-style: italic;">
                We aim to build a facility with the right equipments and the right people to make sure that our customers get the contentment of a quality job. Our team has the ability to exceed expectations and will take care of your work as if it was their own.
                    </div>
               		</div>
               	</div>
               </div>
               </div>


       <!-- FEATURES 13 OUR SERVICES -->


       <!-- ABOUT US 1 -->
       <div class="page-section p-90-cont">
         <div class="container">
           <div class="row mb-100">

             <div class="member col-md-4 col-sm-4 wow fadeInUp">
               <div class="member-image">
                 <!-- <img class="img-circle" src="<?php echo base_url(); ?>assets/images/team/team-21.jpg" alt="img"> -->
               </div>
               <h3>Jessica Atkinson</h3>
               <span>VP Engineering</span>
               <ul class="team-social">
                 <li><a href="#"><span aria-hidden="true" class="social_facebook"></span></a></li>
                 <li><a href="#"><span aria-hidden="true" class="social_twitter"></span></a></li>
                 <li><a href="#"><span aria-hidden="true" class="social_dribbble"></span></a></li>
               </ul>
             </div>

             <div class="member col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="200ms">
               <div class="member-image">
                 <!-- <img class="img-circle" src="<?php echo base_url(); ?>assets/images/team/team-22.jpg" alt="img"> -->
               </div>
               <h3>Ronald Jackson</h3>
               <span>Founder And Ceo</span>
               <ul class="team-social">
                 <li><a href="#"><span aria-hidden="true" class="social_facebook"></span></a></li>
                 <li><a href="#"><span aria-hidden="true" class="social_twitter"></span></a></li>
                 <li><a href="#"><span aria-hidden="true" class="social_dribbble"></span></a></li>
               </ul>
             </div>

             <div class="member col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="400ms">
               <div class="member-image">
                 <!-- <img class="img-circle" src="<?php echo base_url(); ?>assets/images/team/team-23.jpg" alt="img"> -->
               </div>
               <h3>Henry Shelton</h3>
               <span>Creative Director</span>
               <ul class="team-social">
                 <li><a href="#"><span aria-hidden="true" class="social_facebook"></span></a></li>
                 <li><a href="#"><span aria-hidden="true" class="social_twitter"></span></a></li>
                 <li><a href="#"><span aria-hidden="true" class="social_dribbble"></span></a></li>
               </ul>
             </div>

           </div>

         </div>
       </div>


       <script>
       $("#aboutmenu").addClass("current");
       </script>


 <!-- WORK PROCESS 2 -->
