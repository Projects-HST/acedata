<?php
/**
*   Sidebar Right Template
*
*   @file                   sidebar-right.php
*   @package                Black Gold
*   @author                 Lewis Briffa
*   @copyright              2016 L.A.B
*   @license                license.txt
*   @version                Release 1.0
*/
?>

<div class="col-md-1"></div>

<?php get_sidebar(); ?>