<style>
.footer2-copy-cont .clearfix{
  background: #303036;
    color: rgba(255,255,255,.7);
}
</style>
<div class="page-title-cont page-title-large2-cont" style="background-image: url(<?php echo base_url(); ?>assets/page/historybanner.jpg);height:400px;    background-repeat: no-repeat;">
        <div class="relative container align-left">
          <div class="row">

            <div class="col-md-8">
              <h1 class="page-title2" style="text-align:left;"></h1>
            </div>

            <div class="col-md-4">
              <div class="breadcrumbs2 font-poppins">
                <a class="a-inv" href=""></a><span class="slash-divider"></span><span class="bread-current"></span>
              </div>
            </div>

          </div>
        </div>
      </div>


<!-- COTENT CONTAINER -->
<div id="blockquotes2" class="page-section p-70-cont bg-gray" style="background-color: #bc9c85;color:#fff;font-size:18px;">
<div class="container">
  <div class="row">


    <div id="about" class="">
             <div class="container">
               <div>
                 <!-- <h3 class="sl2-text font-josefin" >We Are Ace Data<br></h3> -->

                 <div class="blog2-post-prev-text center" style="text-align:center;padding-bottom:40px;padding-top:50px;font-style: italic;">
                Our history is a reflection of our philosophy, where one can experience bar-raising quality, and expertly printed resources evolved over a period of time.
                 </div>

               </div>
             </div>
            </div>
            </div>
            </div>
            </div>


    <!-- SIDENAV HIDE -->


	<div class="col-md-12">
	<img src="<?php echo base_url(); ?>assets/page/history.jpg" class="img-responsive" style="margin-top:40px;">
	</div>


    <!-- COTENT  -->
  <!-- <div class="col-md-12">


          <section id="cd-timeline" class="cd-container mb-100">
            <div class="cd-timeline-start">
              <div class="cd-timeline-start-caption">The Whole Picture</div>
              <div class="cd-timeline-start-date">1984 - Present</div>
            </div>
            <div class="cd-timeline-block">
              <div class="cd-timeline-img cd-picture">
                <span aria-hidden="true" class="icon_house_alt"></span>
              </div>

              <div class="cd-timeline-content">

                <div>With only screen-printing process, Ace Data has established its 'Brand' in wedding invitations.</div>
                <span class="cd-date"><span class="cd-date-year">1984</span></span>
              </div>
            </div>

            <div class="cd-timeline-block">
              <div class="cd-timeline-img cd-picture">
                <span aria-hidden="true" class="icon_cloud_alt"></span>
              </div>

              <div class="cd-timeline-content">

                <p>Started its first Photo-type-film setting with language fonts imported from the USA</p>
                <span class="cd-date"><span class="cd-date-year">1986 </span></span>
              </div>
            </div>

            <div class="cd-timeline-block">
              <div class="cd-timeline-img cd-picture">
                <span aria-hidden="true" class="icon_heart_alt"></span>
              </div>

              <div class="cd-timeline-content">

                <p>The only Indian member in the Typographers International Association, USA.</p>
                  <p>One among the very few Indian members in the Screen Printing Association International, USA. </p>
                <span class="cd-date"><span class="cd-date-year">1987 </span></span>
              </div>
            </div>

            <div class="cd-timeline-block">
              <div class="cd-timeline-img cd-picture">
                <span aria-hidden="true" class="icon_gift_alt"></span>
              </div>
              <div class="cd-timeline-content">

                <p>  Expanded its operations in Avinashi Road, Coimbatore with a landmark building.</p>
                <span class="cd-date"><span class="cd-date-year">1991</span></span>
              </div>
            </div>

            <div class="cd-timeline-block">
              <div class="cd-timeline-img cd-picture">
                <span aria-hidden="true" class="icon_archive_alt"></span>
              </div>

              <div class="cd-timeline-content">

                <p>First offset printing machine was formally established as the next generation of printers.</p>
                <span class="cd-date"><span class="cd-date-year">1992</span></span>
              </div>
            </div>

             <div class="cd-timeline-block">
               <div class="cd-timeline-img cd-picture">
                 <span aria-hidden="true" class="icon_archive_alt"></span>
               </div>

               <div class="cd-timeline-content">

                 <p>South India’s first printing press to get ISO 9001:2008 Certification in the small-scale segment.</p>
                 <span class="cd-date"><span class="cd-date-year">2002</span></span>
               </div>
             </div>

             <div class="cd-timeline-block">
               <div class="cd-timeline-img cd-picture">
                 <span aria-hidden="true" class="icon_archive_alt"></span>
               </div>

               <div class="cd-timeline-content">

                 <p>Created an astonishing infrastructure for its print production unit.
                 </p>
                 <span class="cd-date"><span class="cd-date-year">2007</span></span>
               </div>
             </div>
            <div class="cd-timeline-start cd-final" style="width:600px;">
              <div class="cd-timeline-start-caption">AT PRESENT</div>
              <p  class=""> ACE DATA unveils the all new German technology printing solutions that caters to all-in-one innovative printhead technology that perform beyond imagination.</p>
            </div>
          </section>
    </div> -->



  </div>
</div>
