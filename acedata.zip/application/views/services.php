<style>
.tab-nav-text.font-poppins {
    width: 100px;
}

.service li{
  padding-left: 15px;
  float: left;
}
.icon-list>li [class*=" fa-"] {
  position: relative;left:-20px;
}
.mb-50{
  text-align: left;
}
.listservices{
  text-align: left;
  list-style-type: unset;
  padding-left: 80px;

}
.listservices ul li{
  text-align: left;
}
.fes14-tab-content{
  padding-bottom: 20px;
}
.fes14-tab-title{
  font-size: 32px;
}
.fes14-nav-tabs > li > a{
	text-align: -moz-center;
}
.img-responsive{padding-bottom:15px;}
.box{
    background-color: #fff;
    padding-top: 10px;
    padding-bottom: 10px;
    border-top: 4px solid #f26422;
    height: 470px;
    margin-bottom: 15px;
}
</style>

      <div class="page-title-cont page-title-large2-cont bg-gray" style="background-image: url(<?php echo base_url(); ?>assets/page/services.jpg);">
        <div class="relative container align-left">
          <div class="row">

            <div class="col-md-8">
              <h1 class="page-title2"></h1>
            </div>

            <div class="col-md-4">
              <div class="breadcrumbs2 font-poppins">
                <a class="a-inv" href=""></a><span class="slash-divider"></span><span class="bread-current"></span>
              </div>
            </div>

          </div>
        </div>
      </div>

<!-- ADS 3 -->

      <!-- ADS 4 -->
      <div id="blockquotes2" class="page-section p-90-cont bg-gray" >
            <div class="container">
              <!-- <blockquote class="bq2-cont text-center ls-1 font-20 pb-0"> -->
                  <p class=" font-18 text-center" style="       font-style: italic;   ">We are good at what we deliver</p>
              <p class="text-center">  <span class="test-quote-before"></span>Complex solutions with attention to every detail our efficient and creative team makes the entire process seamless by providing the highest level of service,reliability, value for money and quality, no matter the assignment.<span class="test-quote-after"></span></p>

              <!-- </blockquote> -->
            </div>
          </div>

      <!-- FEATURES 14 TABS -->
      <div class="page-section p-10-cont bg-gray">
        <div class="container">



          <!-- TABS CONTENT & IMAGES -->
          <!-- <div class="row">

            <!-- TABS CONTENT -->
            <div class="col-md-12 text-center">
              <div class="row">
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/MI.png" class="img-responsive">
                    </center>
                      <h3>MANUFACTURING INDUSTRIES</h3>
                    <ul class="icon-list listservices">
                    <li>Company Profile</li>
                    <li>Product Catalogues</li>
                    <li>Annual Reports</li>
                    <li>Product User Manuals</li>
                    <li>Newsletters</li>
                    <li>Posters</li>
                    <li>Calendars</li>
                    <li>Greeting Cards</li>
                    <li>Invitations</li>
                  </ul>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/ITA.png" class="img-responsive">
                    </center>
                      <h3>INDUSTRY & TRADE ASSOCIATIONS</h3>
                    <ul class="icon-list listservices">
                    <li>Trade Fair Publications</li>
                    <li>News Letters</li>
                    <li>Bulletins</li>
                    <li>Annual Reports</li>
                    <li>Invitations</li>
                    <li>Seminar Publications</li>

                  </ul>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/RS.png" class="img-responsive">
                    </center>
                      <h3>RETAIL SECTION</h3>
                    <ul class="icon-list listservices">
                    <li>Publicity Brochures</li>
                    <li>Calendars</li>
                    <li>Handbills and Mailers</li>
                    <li>Posters</li>
                    <li>Invitations</li>
                    <li>Flyers</li>
                    <li>Greeting Cards</li>

                  </ul>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/EI.png" class="img-responsive">
                    </center>
                      <h3>EDUCATIONAL INSTITUTIONS</h3>
                    <ul class="icon-list listservices">
                    <li>General Facility Brochures</li>
                    <li>Departmental Brochures</li>
                    <li>Placement Profiles</li>
                    <li>Conference Publications</li>
                    <li>Student Exercise Notebooks</li>
                    <li>Posters</li>
                    <li>Souvenirs/Magazines</li>
                    <li>Newsletters</li>
                    <li>College/School Diary/Calendar</li>
                    <li>Greeting Cards</li>
                    <li>Invitations</li>
                  </ul>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/BFI.png" class="img-responsive">
                    </center>
                      <h3>BANKS & FINANCIAL INSTITUTIONS</h3>
                    <ul class="icon-list listservices">
                    <li>Annual Reports</li>
                    <li>Promotional Publications</li>
                    <li>Greeting Cards</li>
                    <li>Invitations</li>

                  </ul>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/BP.png" class="img-responsive">
                    </center>
                      <h3>BOOK PUBLISHERS</h3>
                    <ul class="icon-list listservices">
                      <li>Books</li>
                        <li>Posters</li>
                        <li>Book Review Brochures</li>
                        <li>Catalogue of Books</li>
                        <li>Newsletters</li>

                  </ul>
                  </div>

                </div>
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/AT.png" class="img-responsive">
                    </center>
                      <h3>APPAREL & TEXTILE</h3>
                    <ul class="icon-list listservices">
                      <li>General Facility Brochures</li>
                       <li>Product Brochures</li>
                       <li>Tags</li>
                       <li>Insert Cards</li>
                       <li>Folders</li>
                       <li>Posters</li>
                       <li>Annual Reports</li>
                       <li>Greeting Cards</li>
                       <li>Invitations</li>
                  </ul>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/hi.png" class="img-responsive">
                    </center>
                      <h3>HOSPITALITY INDUSTRY</h3>
                    <ul class="icon-list listservices">
                      <li>Table Menu</li>
                     <li>Table Place Mats</li>
                     <li>Newsletters</li>
                     <li>Posters</li>
                     <li>Greeting Cards</li>
                     <li>Invitations</li>
                  </ul>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="box">
                    <center><img src="<?php echo base_url(); ?>assets/page/icons/HC.png" class="img-responsive">
                    </center>
                      <h3>HEALTH CARE</h3>
                    <ul class="icon-list listservices">
                      <li>General Facility Brochure</li>
                       <li>Departmental Brochures</li>
                       <li>Newsletters</li>
                       <li>Posters</li>
                       <li>Calendars</li>
                       <li>Invitations</li>
                       <li>Greeting Cards</li>
                  </ul>
                  </div>
                </div>
              </div>

            </div>

            <!-- IMAGES -->


          </div>
        </div>
      </div>
