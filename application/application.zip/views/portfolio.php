<div class="page-title-cont page-title-large2-cont bg-gray" style="background-image: url(<?php echo base_url(); ?>assets/images/bg-about-us.jpg);">
         <div class="relative container align-left">
           <div class="row">

             <div class="col-md-8">
               <h1 class="page-title2">Portfolio</h1>
             </div>

             <div class="col-md-4">
               <div class="breadcrumbs2 font-poppins">
                 <a class="a-inv" href="">home</a><span class="slash-divider">/</span><span class="bread-current">portfolio</span>
               </div>
             </div>

           </div>
         </div>
       </div>

       <!-- COTENT CONTAINER -->
  <div class="container">
       <div class="pt-50 pb-30 pt-xxs-80">

         <div class="relative">
           <!-- PORTFOLIO FILTER -->
           <div class="container">

             <ul class="port-filter font-poppins">
               <li>
                 <a href="#" class="filter active" data-filter="*">All Projects</a>
               </li>
               <li>
                 <a href="#" class="filter" data-filter=".development">Development</a>
               </li>
               <li>
                 <a href="#" class="filter" data-filter=".design">Design</a>
               </li>
               <li>
                 <a href="#" class="filter" data-filter=".photography">Photography</a>
               </li>
             </ul>

           </div>

           <!-- ITEMS GRID -->
           <ul class="port-grid port-grid-3 clearfix" id="items-grid">

             <!-- Item 1 -->
             <li class="port-item mix design">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-1-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Minimalism</h3>
                     <span>design</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 2 -->
             <li class="port-item mix photography">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-2-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Iceland Beach</h3>
                     <span>photography</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 3 -->
             <li class="port-item mix photography">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-3-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Metal Bridge</h3>
                     <span>photography</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 4 -->
             <li class="port-item mix design">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-7-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Brochure Design</h3>
                     <span>design</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 5 -->
             <li class="port-item mix photography">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-6-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Black White Surfer</h3>
                     <span>photography</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 6 -->
             <li class="port-item mix development">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-4-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Minimalist Watches</h3>
                     <span>development</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 7 -->
             <li class="port-item mix development">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-17-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Architecture</h3>
                     <span>development</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 8 -->
             <li class="port-item mix photography">
               <a href="">
                 <div class="port-img-overlay">
                   <img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-5-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Swimming Pool</h3>
                     <span>photography</span>
                   </div>
                 </div>
               </a>
             </li>

             <!-- Item 9 -->
             <li class="port-item mix development">
               <a href="">
                 <div class="port-img-overlay"><img class="port-main-img" src="<?php echo base_url(); ?>assets/images/portfolio/projects-8-3col.jpg" alt="img" >
                 </div>
                 <div class="port-overlay-cont">
                   <div class="port-title-cont2">
                     <h3>Spacesuit</h3>
                     <span>development</span>
                   </div>
                 </div>
               </a>
             </li>

           </ul>

         </div>


       </div>
   </div>
