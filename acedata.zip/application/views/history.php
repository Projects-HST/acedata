<style>
.footer2-copy-cont .clearfix{
  background: #303036;
    color: rgba(255,255,255,.7);
}
</style>
<div class="page-title-cont page-title-large2-cont histback" style="background-image: url(<?php echo base_url(); ?>assets/page/historybanner.jpg);  background-size: 100%;   background-repeat: no-repeat;">
        <div class="relative container align-left">
          <div class="row">

            <div class="col-md-8">
              <h1 class="page-title2" style="text-align:left;"></h1>
            </div>

            <div class="col-md-4">
              <div class="breadcrumbs2 font-poppins">
                <a class="a-inv" href=""></a><span class="slash-divider"></span><span class="bread-current"></span>
              </div>
            </div>

          </div>
        </div>
      </div>


<!-- COTENT CONTAINER -->
<div id="blockquotes2" class="page-section p-70-cont bg-gray" style="background-color: #bc9c85;color:#fff;font-size:18px;">
<div class="container">
  <div class="row">


    <div id="about" class="">
             <div class="container">
               <div>
                 <!-- <h3 class="sl2-text font-josefin" >We Are Ace Data<br></h3> -->

                 <div class="blog2-post-prev-text center" style="text-align:center;padding-bottom:40px;padding-top:50px;font-style: italic;">
                Our history is a reflection of our philosophy, where one can experience bar-raising quality, and expertly printed resources evolved over a period of time.
                 </div>

               </div>
             </div>
            </div>
            </div>
            </div>
            </div>


    <!-- SIDENAV HIDE -->


	<div class="col-md-12">
	<img src="<?php echo base_url(); ?>assets/page/history.jpg" class="img-responsive" style="margin-top:40px;">
	</div>



  </div>
</div>
<script>
$("#aboutmenu").addClass("current");
</script>
